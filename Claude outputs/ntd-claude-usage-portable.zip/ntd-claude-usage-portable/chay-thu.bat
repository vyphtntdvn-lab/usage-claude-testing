@echo off
REM ============================================================
REM  Gom usage Claude Code tren may nay -> CSV + SUMMARY.md
REM  Ban nay KHONG dung toi git (PUSH_DISABLED = True).
REM
REM  Cach dung:
REM    chay-thu.bat --dry-run           chi in so lieu, khong ghi file
REM    chay-thu.bat                     ghi CSV + SUMMARY.md
REM    chay-thu.bat --machine TenMay    tu dat ten may (mac dinh: hostname)
REM ============================================================
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo Khong tim thay python trong PATH.
    echo Cai Python 3.7+ roi chay lai, hoac goi truc tiep:
    echo    "C:\duong\dan\python.exe" tools\claude_usage.py
    pause
    exit /b 1
)
python tools\claude_usage.py %*
echo.
pause
