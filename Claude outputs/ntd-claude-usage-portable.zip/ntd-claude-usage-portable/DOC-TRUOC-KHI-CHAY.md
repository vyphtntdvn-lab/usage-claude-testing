# Bộ chạy thử độc lập — Claude Code usage

Bản này **không dùng tới git**. Cứ copy nguyên thư mục sang máy khác là chạy được.
Nó chỉ đọc transcript rồi ghi ra file trong chính thư mục này — không đụng gì tới
máy đó ngoài hai thư mục/file nó tự tạo.

## Cần gì

- Python **3.7 trở lên** (`python --version` để kiểm tra)
- Máy đích đã dùng Claude Code, tức là có sẵn thư mục `~/.claude/projects`
  (Windows: `C:\Users\<tên>\.claude\projects`)

Không cần cài thư viện ngoài. Không cần git. Không cần mạng.

## Chạy

```
chay-thu.bat --dry-run        # chỉ in số ra màn hình, KHÔNG ghi file nào
chay-thu.bat                  # ghi data\<tên máy>\<tháng>.csv + SUMMARY.md
chay-thu.bat --machine May2   # tự đặt tên máy (mặc định lấy hostname)
```

macOS / Linux thì dùng `./chay-thu.sh` với cùng tham số.

Lần đầu nên chạy `--dry-run` trước để xem có quét ra dữ liệu không.

## Nó tạo ra gì

```
data/<tên máy>/<tháng>.csv    số liệu gốc, mỗi dòng một (ngày, project, session, agent, model)
SUMMARY.md                    bảng tổng hợp dễ đọc
.run.log                      nhật ký mỗi lần chạy
```

Chạy lại bao nhiêu lần cũng ra kết quả y hệt — mỗi lần nó quét lại toàn bộ
transcript và ghi đè, không cộng dồn chồng lên nhau.

## Ý nghĩa các cột CSV

| Cột | Nghĩa |
|---|---|
| `input` / `output` | Token vào / ra, **không** bao gồm token cache |
| `cache_write_5m` | Token ghi cache TTL 5 phút |
| `cache_write_1h` | Token ghi cache TTL 1 giờ (giá cao hơn 5m nên phải tách riêng) |
| `cache_read` | Token đọc cache — **phần lớn tiền nằm ở đây** |
| `cost_usd` | Tự tính từ 5 cột trên × bảng giá trong `pricing.json` |

Muốn kiểm tra lại tiền thì mở `pricing.json` rồi tự nhân tay:
`cost = (input×giá_input + output×giá_output + cache_write_5m×giá_5m
+ cache_write_1h×giá_1h + cache_read×giá_read) / 1.000.000`, cộng thêm
$0.01 cho mỗi lần web search. Không có bước làm tròn ẩn nào.

## Lưu ý

- Chỉ đọc profile mặc định `~/.claude`. Các profile khác
  (`~/.claude-personal`, `~/.claude-work`...) **không** được tính.
- Model chưa có trong `pricing.json` sẽ bị tính `cost = 0`, kèm dòng
  `CANH BAO:` in ra màn hình và ghi vào `.run.log`. Nhớ ngó dòng đó.
- Ngày được quy về **giờ địa phương của máy đang chạy**. Chạy hai máy lệch
  múi giờ thì ranh giới ngày sẽ khác nhau.
- Muốn bật lại chế độ tự commit + push lên git: mở `tools/claude_usage.py`,
  đổi `PUSH_DISABLED = True` thành `False`.
