#!/usr/bin/env bash
# Ban cho macOS / Linux. Xem chay-thu.bat de biet cac tham so.
cd "$(dirname "$0")" || exit 1
exec python3 tools/claude_usage.py "$@"
